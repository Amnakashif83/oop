/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mybook;

/**
 *
 * @author HP
 */
public class Mybook {
 public static void main(String[] args) {
        Library library = new Library();
        library.addBook(new Book(1, "The Alchemist", "Paulo Coelho"));
        library.addBook(new Book(2, "1984", "George Orwell"));
        library.addBook(new Book(3, "To Kill a Mockingbird", "Harper Lee"));
        
        System.out.println("\nAll Books in Library:");
        library.displayAllBooks();
        
        library.removeBook(2);
        System.out.println("\nAfter Removing Book with ID 2:");
        library.displayAllBooks();
    }
}
