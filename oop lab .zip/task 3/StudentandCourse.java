/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentandcourse;

/**
 *
 * @author HP
 */
public class StudentandCourse {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
