/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mybook;

/**
 *
 * @author HP
 */
import java.util.ArrayList;
public class Library {
     private ArrayList<Book> books = new ArrayList<>();
    
    public void addBook(Book book) {
        books.add(book);
    }
    
    public void removeBook(int bookID) {
        books.removeIf(book -> book.getBookID() == bookID);
    }
    
    public void displayAllBooks() {
        for (Book book : books) {
            book.displayBook();
        }
    }
    
}
