/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalsystem;

/**
 *
 * @author HP
 */
import java.util.ArrayList;
import java.util.List;

public class Doctor {
     private String name;
    private String specialization;
    private int experienceYears;
    private List<String> patients;

    public Doctor(String name, String specialization, int experienceYears) {
        this.name = name;
        this.specialization = specialization;
        this.experienceYears = experienceYears;
        this.patients = new ArrayList<>();
    }

    public void addPatient(String patientName) {
        patients.add(patientName);
    }

    public void showDoctorInfo() {
        System.out.println("Doctor Name: " + name);
        System.out.println("Specialization: " + specialization);
        System.out.println("Experience: " + experienceYears + " years");
        System.out.println("Patients: " + patients);
    }

    public String getName() {
        return name;
    }
    
}
