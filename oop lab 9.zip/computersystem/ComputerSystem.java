/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.computersystem;

/**
 *
 * @author HP
 */
public class ComputerSystem {

    public static void main(String[] args) {
        Computer comp = new Computer("Dell", "Intel i7-12700H", 3.5, 8, 16, 3200);
        
        comp.showComputerSpecs();
        comp.runProgram();
        comp.showComputerSpecs();
        comp.stopProgram();
        comp.showComputerSpecs();
     
    }
}
