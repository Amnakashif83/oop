/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.computersystem;

/**
 *
 * @author HP
 */
public class Processor {
    private String model;
        private double speedGHz;
        private int cores;

        public Processor(String model, double speedGHz, int cores) {
            this.model = model;
            this.speedGHz = speedGHz;
            this.cores = cores;
        }

        public void displaySpecs() {
            System.out.println("Processor Model: " + model);
            System.out.println("Processor Speed: " + speedGHz + " GHz");
            System.out.println("Processor Cores: " + cores);
        }  
}
