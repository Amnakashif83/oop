/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.computersystem;

/**
 *
 * @author HP
 */
public class RAM {
     private int capacityGB;
        private int speedMHz;

        public RAM(int capacityGB, int speedMHz) {
            this.capacityGB = capacityGB;
            this.speedMHz = speedMHz;
        }

        public void displaySpecs() {
            System.out.println("RAM Capacity: " + capacityGB + " GB");
            System.out.println("RAM Speed: " + speedMHz + " MHz");
        }
    }

