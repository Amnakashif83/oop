/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.computersystem;

/**
 *
 * @author HP
 */
public class Computer {
    private String brand;
    private Processor processor;
    private RAM ram;
    private boolean isRunningProgram;

    public Computer(String brand, String processorModel, double processorSpeed, int cores,
                    int ramCapacity, int ramSpeed) {
        this.brand = brand;
        this.processor = new Processor(processorModel, processorSpeed, cores);
        this.ram = new RAM(ramCapacity, ramSpeed);
        this.isRunningProgram = false;
    }
    public void runProgram() {
        isRunningProgram = true;
        System.out.println("The computer is now running a program.");
    }
    public void stopProgram() {
        isRunningProgram = false;
        System.out.println("The computer has stopped running the program.");
    }
    public void showProcessorSpecs() {
        processor.displaySpecs();
    }
    public void showRamSpecs() {
        ram.displaySpecs();
    }
    public void showComputerSpecs() {
        System.out.println("=== Computer Specs ===");
        System.out.println("Brand: " + brand);
        processor.displaySpecs();
        ram.displaySpecs();
        System.out.println("Is running program: " + (isRunningProgram ? "Yes" : "No")); 
    }}


