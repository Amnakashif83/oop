/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
import java.util.ArrayList;
import java.util.List;
public class Course {
    private String title;
    private String courseCode;
    private List<Student> enrolledStudents;

    public Course(String title, String courseCode) {
        this.title = title;
        this.courseCode = courseCode;
        this.enrolledStudents = new ArrayList<>();
    }

    public void enrollStudent(Student student) {
        if (!enrolledStudents.contains(student)) {
            enrolledStudents.add(student);
            System.out.println(student.getStudentId() + " enrolled in " + title);
        } else {
            System.out.println("Student already enrolled.");
        }
    }

    public void removeStudent(String studentId) {
        for (Student s : enrolledStudents) {
            if (s.getStudentId().equals(studentId)) {
                enrolledStudents.remove(s);
                System.out.println("Student " + studentId + " removed from " + title);
                return;
            }
        }
        System.out.println("Student not found in this course.");
    }

    public void showEnrolledStudents() {
        System.out.println("Students enrolled in " + title + ":");
        for (Student s : enrolledStudents) {
            s.showStudentInfo();
            
        }
    }

    public void showCourseInfo() {
        System.out.println("Course Title: " + title);
        System.out.println("Course Code: " + courseCode);
        System.out.println("Total Students Enrolled: " + enrolledStudents.size());
    }
    
}
