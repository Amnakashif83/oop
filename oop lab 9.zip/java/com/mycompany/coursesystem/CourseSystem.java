/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.coursesystem;

/**
 *
 * @author HP
 */
public class CourseSystem {

    public static void main(String[] args) {
         Student s1 = new Student("Alice Johnson", "S101", "alice@example.com");
        Student s2 = new Student("Bob Smith", "S102", "bob@example.com");

        // Create a course
        Course javaCourse = new Course("Java Programming", "CS101");

        // Enroll students
        javaCourse.enrollStudent(s1);
        javaCourse.enrollStudent(s2);

        // Students submitting assignments
        s1.submitAssignment("Assignment 1");
        s2.submitAssignment("Assignment 1");

        // Show course info and enrolled students
        javaCourse.showCourseInfo();
        javaCourse.showEnrolledStudents();

        // Remove a student
        javaCourse.removeStudent("S101");

        // Show updated list
        javaCourse.showEnrolledStudents();
    }
        
    }

