/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class Student {
     private String name;
    private String studentId;
    private String email;

    public Student(String name, String studentId, String email) {
        this.name = name;
        this.studentId = studentId;
        this.email = email;
    }

    public void submitAssignment(String assignmentTitle) {
        System.out.println(name + " has submitted the assignment: " + assignmentTitle);
    }

    public void showStudentInfo() {
        System.out.println("Name: " + name);
        System.out.println("Student ID: " + studentId);
        System.out.println("Email: " + email);
    }

    public String getStudentId() {
        return studentId;
    }
    
}
