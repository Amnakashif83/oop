/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.homeautomation;

/**
 *
 * @author HP
 */
public class SmartSpeaker implements RemoteControl {
     public void turnOn() {
        System.out.println("SmartSpeaker is now ON. play your music!");
    }

    public void turnOff() {
        System.out.println("SmartSpeaker is now OFF. Goodbye!");
    }
}
