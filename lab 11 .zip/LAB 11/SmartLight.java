/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.homeautomation;

/**
 *
 * @author HP
 */
public class SmartLight implements RemoteControl {
    public void turnOn() {
        System.out.println("SmartLight is now ON. Let there be light!");
    }

    public void turnOff() {
        System.out.println("SmartLight is now OFF. Lights out!");
    }
}
