/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.homeautomation;

/**
 *
 * @author HP
 */
public class SmartTV implements RemoteControl {
     public void turnOn() {
        System.out.println("SmartTV is now ON. Enjoy your favorite shows!");
    }

    public void turnOff() {
        System.out.println("SmartTV is now OFF. See you later!");
    }
    
}
