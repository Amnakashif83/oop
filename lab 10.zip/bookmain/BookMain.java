/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bookmain;

/**
 *
 * @author HP
 */
public class BookMain {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
